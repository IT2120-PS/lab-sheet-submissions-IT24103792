setwd("C:\\Users\\it24103792\\Desktop\\IT24103792")
data<-read.table("DATA 4.txt",header=TRUE,sep=" ")
fix(data)
attach(data)
boxplot(X1, main="Box plot for Team Attendance", outline=TRUE, outpch=8, horizontal=TRUE)
boxplot(X2, main="Box plot for Team Salary", outline=TRUE, outpch=8, horizontal=TRUE)
boxplot(X3, main="Box plot for Years", outline=TRUE, outpch=8, horizontal=TRUE)

hist(X1, ylab="Frequency", xlab="Team Attendance", main="Histogram for Team Attendance")
hist(X2, ylab="Frequency", xlab="Team Salary", main="Histogram for Team Salary")
hist(X3, ylab="Frequency", xlab="Years", main="Histogram for Years")

stem(X1)
stem(X2)
stem(X3)

mean(X1)
mean(X2)
mean(X3)

median(X1)
median(X2)
median(X3)

sd(X1)
sd(X2)
sd(X3)

#execise


branch_data <- read.table("Exercise.txt", header=TRUE, sep=",")
head(branch_data)
fix(data)
attach(data)

str(branch_data)


boxplot(branch_data$Sales_X1,main="Box plot for sales",ylab="sales")

fivenum(branch_data$Advertising_X2)

find_outliers<-function(x){
  q1<-quantile(x,0.25)
  q3<-quantile(x,0.75)
  IQR_value<-q3-q1
  lower<-q1-1.5*IQR_value
  upper<-q3+1.5*IQR_value
  outliers<-x[x<lower|x>upper]
  return(outliers)
}

